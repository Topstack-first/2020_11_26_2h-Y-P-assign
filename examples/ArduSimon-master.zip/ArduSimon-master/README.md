# ArduSimon
My implementation for Arduino of the famous Simon game
