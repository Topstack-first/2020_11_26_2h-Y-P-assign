SIMON GAME
----------

## History:
"Simon Electronic Memory Game" is a game project that I realized in order to put into practice my learning of JavaScript and Jquery through my 3 months training with Google and Udacity.

## Purpose:

SIMON is a robot that will perform a series of random color, the goal of the game is to memorize this sequence and reproduce it. Each sequence performed correctly will make you level up and each level up adds 1 color. The objective is to have the highest level! Good game!

----------
Test your website for cross browser compatibility on real browsers : [https://www.browserstack.com/](https://www.browserstack.com/)
![BrowserStack](https://bstacksupport.zendesk.com/attachments/token/msH5XoqTXHPDw3K344u6LQ5co/?name=browserstack-logo-600x315.png)

