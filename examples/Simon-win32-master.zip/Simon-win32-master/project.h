#include <windows.h>

#define ID_TEXT     100
#define BUTTON_1    101
#define BUTTON_2    102
#define BUTTON_3    103
#define BUTTON_4    104
#define BUTTON_START     106
#define DIALOG_BUTTON 105

#define ID_FILE_EXIT 9001
#define ID_STUFF_GO 9002
#define HARD_START 9003
#define ID_MYMENU 1000
