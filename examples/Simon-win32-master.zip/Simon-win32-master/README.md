# Simon-win32
A implementation of the board game Simon to practice with the Widows API
